package monteiro.andre;
//André Monteiro Sanches Garcia 19.01230-6
import monteiro.andre.models.Sistema;

/**
 * Onde ira ser implementada a classe Sistema
 */
public class Main {

    public static void main(String[] args) {
	Sistema sistema = new Sistema();
	sistema.execute();
    }
}
