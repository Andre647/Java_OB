package monteiro.andre.interfaces;

/**
 * Interface responsavel por apresentar os membros
 */
public interface Apresentacao {
    void apresentar();
}
