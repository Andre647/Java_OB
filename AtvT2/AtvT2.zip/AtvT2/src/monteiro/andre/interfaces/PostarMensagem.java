package monteiro.andre.interfaces;

/**
 * Interface responsavel pela mensagem
 */
public interface PostarMensagem {
    void mensagemNormal();
    void mensagemExtra();
}
