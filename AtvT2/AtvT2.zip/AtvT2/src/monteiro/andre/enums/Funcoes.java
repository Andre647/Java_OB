package monteiro.andre.enums;


/**
 * ENUM com as funcoes possiveis de cada membro
 */
public enum Funcoes  {
    MOBILE_MEMBERS,HEAVY_LIFTERS,SCRIPT_GUYS,BIG_BROTHERS
}
