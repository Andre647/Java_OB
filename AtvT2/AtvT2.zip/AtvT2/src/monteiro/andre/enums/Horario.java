package monteiro.andre.enums;

/**
 * Classe ENUM com 2 tipos de horario -> NORMAL/EXTRA
 */
public enum Horario {
    NORMAL,EXTRA
}
